module para_partial_sort_inner (
        ap_clk,
        ap_rst_n,
        ap_start,
        ap_done,
        ap_idle,
        ap_ready,
        PE_idx,
        compute_to_sort_stream,
        sort_to_hiermerge_dist_stream,
        sort_to_hiermerge_dist_stream_ap_vld,
        sort_to_hiermerge_id_stream,
        sort_to_hiermerge_id_stream_ap_vld
);

parameter    ap_ST_fsm_state1 = 5'd1;
parameter    ap_ST_fsm_state2 = 5'd2;
parameter    ap_ST_fsm_state3 = 5'd4;
parameter    ap_ST_fsm_state4 = 5'd8;
parameter    ap_ST_fsm_state5 = 5'd16;

input   ap_clk;
input   ap_rst_n;
input   ap_start;
output   ap_done;
output   ap_idle;
output   ap_ready;
input  [31:0] PE_idx;
input  [31:0] compute_to_sort_stream;
output  [31:0] sort_to_hiermerge_dist_stream;
output   sort_to_hiermerge_dist_stream_ap_vld;
output  [31:0] sort_to_hiermerge_id_stream;
output   sort_to_hiermerge_id_stream_ap_vld;

reg ap_done;
reg ap_idle;
reg ap_ready;
reg sort_to_hiermerge_dist_stream_ap_vld;
reg sort_to_hiermerge_id_stream_ap_vld;

 reg    ap_rst_n_inv;
(* fsm_encoding = "none" *) reg   [4:0] ap_CS_fsm;
wire    ap_CS_fsm_state1;
wire   [31:0] start_id_fu_205_p2;
reg   [31:0] start_id_reg_432;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_start;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_done;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_idle;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_ready;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out1;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out1_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out2;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out2_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out3;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out3_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out4;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out4_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out5;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out5_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out6;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out6_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out7;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out7_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out8;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out8_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out9;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out9_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out10;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out10_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out11;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out11_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out12;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out12_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out13;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out13_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out14;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out14_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out15;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out15_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out16;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out16_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out17;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out17_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out18;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out18_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_0_0_0138_out;
wire    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_0_0_0138_out_ap_vld;
wire    grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_start;
wire    grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_done;
wire    grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_idle;
wire    grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_ready;
wire   [31:0] grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_p_phi_out;
wire    grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_p_phi_out_ap_vld;
wire   [31:0] grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_p_phi2_out;
wire    grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_p_phi2_out_ap_vld;
reg    grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_start_reg;
wire    ap_CS_fsm_state2;
reg    grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_start_reg;
wire    ap_CS_fsm_state3;
wire    ap_CS_fsm_state4;
wire    ap_CS_fsm_state5;
reg   [4:0] ap_NS_fsm;
reg    ap_ST_fsm_state1_blk;
reg    ap_ST_fsm_state2_blk;
wire    ap_ST_fsm_state3_blk;
reg    ap_ST_fsm_state4_blk;
wire    ap_ST_fsm_state5_blk;
wire    ap_ce_reg;

// power-on initialization
initial begin
#0 ap_CS_fsm = 5'd1;
#0 grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_start_reg = 1'b0;
#0 grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_start_reg = 1'b0;
end

para_partial_sort_para_partial_sort_Pipeline_SORT_LOOP grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152(
    .ap_clk(ap_clk),
    .ap_rst(ap_rst_n_inv),
    .ap_start(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_start),
    .ap_done(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_done),
    .ap_idle(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_idle),
    .ap_ready(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_ready),
    .compute_to_sort_stream_load(compute_to_sort_stream),
    .empty(start_id_reg_432),
    .p_out(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out),
    .p_out_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out_ap_vld),
    .p_out1(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out1),
    .p_out1_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out1_ap_vld),
    .p_out2(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out2),
    .p_out2_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out2_ap_vld),
    .p_out3(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out3),
    .p_out3_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out3_ap_vld),
    .p_out4(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out4),
    .p_out4_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out4_ap_vld),
    .p_out5(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out5),
    .p_out5_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out5_ap_vld),
    .p_out6(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out6),
    .p_out6_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out6_ap_vld),
    .p_out7(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out7),
    .p_out7_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out7_ap_vld),
    .p_out8(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out8),
    .p_out8_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out8_ap_vld),
    .p_out9(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out9),
    .p_out9_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out9_ap_vld),
    .p_out10(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out10),
    .p_out10_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out10_ap_vld),
    .p_out11(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out11),
    .p_out11_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out11_ap_vld),
    .p_out12(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out12),
    .p_out12_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out12_ap_vld),
    .p_out13(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out13),
    .p_out13_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out13_ap_vld),
    .p_out14(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out14),
    .p_out14_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out14_ap_vld),
    .p_out15(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out15),
    .p_out15_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out15_ap_vld),
    .p_out16(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out16),
    .p_out16_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out16_ap_vld),
    .p_out17(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out17),
    .p_out17_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out17_ap_vld),
    .p_out18(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out18),
    .p_out18_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out18_ap_vld),
    .p_0_0_0138_out(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_0_0_0138_out),
    .p_0_0_0138_out_ap_vld(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_0_0_0138_out_ap_vld)
);

para_partial_sort_para_partial_sort_Pipeline_OUTPUT_LOOP grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179(
    .ap_clk(ap_clk),
    .ap_rst(ap_rst_n_inv),
    .ap_start(grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_start),
    .ap_done(grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_done),
    .ap_idle(grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_idle),
    .ap_ready(grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_ready),
    .p_0_0_0138_reload(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_0_0_0138_out),
    .p_reload55(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out18),
    .p_reload54(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out17),
    .p_reload53(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out16),
    .p_reload52(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out15),
    .p_reload51(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out14),
    .p_reload50(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out13),
    .p_reload49(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out12),
    .p_reload48(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out11),
    .p_reload47(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out10),
    .p_reload46(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out9),
    .p_reload45(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out8),
    .p_reload44(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out7),
    .p_reload43(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out6),
    .p_reload42(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out5),
    .p_reload41(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out4),
    .p_reload40(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out3),
    .p_reload39(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out2),
    .p_reload38(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out1),
    .p_reload(grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_p_out),
    .p_phi_out(grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_p_phi_out),
    .p_phi_out_ap_vld(grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_p_phi_out_ap_vld),
    .p_phi2_out(grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_p_phi2_out),
    .p_phi2_out_ap_vld(grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_p_phi2_out_ap_vld)
);

always @ (posedge ap_clk) begin
    if (ap_rst_n_inv == 1'b1) begin
        ap_CS_fsm <= ap_ST_fsm_state1;
    end else begin
        ap_CS_fsm <= ap_NS_fsm;
    end
end

always @ (posedge ap_clk) begin
    if (ap_rst_n_inv == 1'b1) begin
        grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_start_reg <= 1'b0;
    end else begin
        if ((1'b1 == ap_CS_fsm_state3)) begin
            grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_start_reg <= 1'b1;
        end else if ((grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_ready == 1'b1)) begin
            grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_start_reg <= 1'b0;
        end
    end
end

always @ (posedge ap_clk) begin
    if (ap_rst_n_inv == 1'b1) begin
        grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_start_reg <= 1'b0;
    end else begin
        if (((1'b1 == ap_CS_fsm_state1) & (ap_start == 1'b1))) begin
            grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_start_reg <= 1'b1;
        end else if ((grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_ready == 1'b1)) begin
            grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_start_reg <= 1'b0;
        end
    end
end

always @ (posedge ap_clk) begin
    if ((1'b1 == ap_CS_fsm_state1)) begin
        start_id_reg_432[31 : 17] <= start_id_fu_205_p2[31 : 17];
    end
end

always @ (*) begin
    if ((ap_start == 1'b0)) begin
        ap_ST_fsm_state1_blk = 1'b1;
    end else begin
        ap_ST_fsm_state1_blk = 1'b0;
    end
end

always @ (*) begin
    if ((grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_done == 1'b0)) begin
        ap_ST_fsm_state2_blk = 1'b1;
    end else begin
        ap_ST_fsm_state2_blk = 1'b0;
    end
end

assign ap_ST_fsm_state3_blk = 1'b0;

always @ (*) begin
    if ((grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_done == 1'b0)) begin
        ap_ST_fsm_state4_blk = 1'b1;
    end else begin
        ap_ST_fsm_state4_blk = 1'b0;
    end
end

assign ap_ST_fsm_state5_blk = 1'b0;

always @ (*) begin
    if ((1'b1 == ap_CS_fsm_state5)) begin
        ap_done = 1'b1;
    end else begin
        ap_done = 1'b0;
    end
end

always @ (*) begin
    if (((1'b1 == ap_CS_fsm_state1) & (ap_start == 1'b0))) begin
        ap_idle = 1'b1;
    end else begin
        ap_idle = 1'b0;
    end
end

always @ (*) begin
    if ((1'b1 == ap_CS_fsm_state5)) begin
        ap_ready = 1'b1;
    end else begin
        ap_ready = 1'b0;
    end
end

always @ (*) begin
    if ((1'b1 == ap_CS_fsm_state5)) begin
        sort_to_hiermerge_dist_stream_ap_vld = 1'b1;
    end else begin
        sort_to_hiermerge_dist_stream_ap_vld = 1'b0;
    end
end

always @ (*) begin
    if ((1'b1 == ap_CS_fsm_state5)) begin
        sort_to_hiermerge_id_stream_ap_vld = 1'b1;
    end else begin
        sort_to_hiermerge_id_stream_ap_vld = 1'b0;
    end
end

always @ (*) begin
    case (ap_CS_fsm)
        ap_ST_fsm_state1 : begin
            if (((1'b1 == ap_CS_fsm_state1) & (ap_start == 1'b1))) begin
                ap_NS_fsm = ap_ST_fsm_state2;
            end else begin
                ap_NS_fsm = ap_ST_fsm_state1;
            end
        end
        ap_ST_fsm_state2 : begin
            if (((grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_done == 1'b1) & (1'b1 == ap_CS_fsm_state2))) begin
                ap_NS_fsm = ap_ST_fsm_state3;
            end else begin
                ap_NS_fsm = ap_ST_fsm_state2;
            end
        end
        ap_ST_fsm_state3 : begin
            ap_NS_fsm = ap_ST_fsm_state4;
        end
        ap_ST_fsm_state4 : begin
            if (((grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_done == 1'b1) & (1'b1 == ap_CS_fsm_state4))) begin
                ap_NS_fsm = ap_ST_fsm_state5;
            end else begin
                ap_NS_fsm = ap_ST_fsm_state4;
            end
        end
        ap_ST_fsm_state5 : begin
            ap_NS_fsm = ap_ST_fsm_state1;
        end
        default : begin
            ap_NS_fsm = 'bx;
        end
    endcase
end

assign ap_CS_fsm_state1 = ap_CS_fsm[32'd0];

assign ap_CS_fsm_state2 = ap_CS_fsm[32'd1];

assign ap_CS_fsm_state3 = ap_CS_fsm[32'd2];

assign ap_CS_fsm_state4 = ap_CS_fsm[32'd3];

assign ap_CS_fsm_state5 = ap_CS_fsm[32'd4];

always @ (*) begin
    ap_rst_n_inv = ~ap_rst_n;
end

assign grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_start = grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_ap_start_reg;

assign grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_start = grp_para_partial_sort_Pipeline_SORT_LOOP_fu_152_ap_start_reg;

assign sort_to_hiermerge_dist_stream = grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_p_phi_out;

assign sort_to_hiermerge_id_stream = grp_para_partial_sort_Pipeline_OUTPUT_LOOP_fu_179_p_phi2_out;

assign start_id_fu_205_p2 = PE_idx << 32'd17;

always @ (posedge ap_clk) begin
    start_id_reg_432[16:0] <= 17'b00000000000000000;
end

endmodule