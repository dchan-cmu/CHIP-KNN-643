module compute_KNN_inner (
        ap_clk,
        ap_rst_n,
        ap_start,
        ap_done,
        ap_idle,
        ap_ready,
        debug_pe_idx,
        debug_start_idx,
        load_to_compute_stream,
        compute_to_sort_stream,
        compute_to_sort_stream_ap_vld
);

parameter    ap_ST_fsm_state1 = 5'd1;
parameter    ap_ST_fsm_state2 = 5'd2;
parameter    ap_ST_fsm_state3 = 5'd4;
parameter    ap_ST_fsm_state4 = 5'd8;
parameter    ap_ST_fsm_state5 = 5'd16;

input   ap_clk;
input   ap_rst_n;
input   ap_start;
output   ap_done;
output   ap_idle;
output   ap_ready;
input  [31:0] debug_pe_idx;
input  [31:0] debug_start_idx;
input  [127:0] load_to_compute_stream;
output  [31:0] compute_to_sort_stream;
output   compute_to_sort_stream_ap_vld;

reg ap_done;
reg ap_idle;
reg ap_ready;
reg compute_to_sort_stream_ap_vld;

 reg    ap_rst_n_inv;
(* fsm_encoding = "none" *) reg   [4:0] ap_CS_fsm;
wire    ap_CS_fsm_state1;
reg   [4:0] indvars_iv114_load_reg_579;
wire    ap_CS_fsm_state2;
wire   [4:0] sub_ln30_fu_290_p2;
reg   [4:0] sub_ln30_reg_584;
wire   [31:0] trunc_ln61_fu_399_p1;
reg   [31:0] trunc_ln61_reg_669;
reg   [31:0] sp_dim_item_value_s_reg_674;
reg   [31:0] sp_dim_item_value_1_reg_679;
reg   [31:0] sp_dim_item_value_2_reg_684;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_start;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_done;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_idle;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_ready;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_31_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_31_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_30_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_30_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_29_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_29_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_28_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_28_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_27_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_27_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_26_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_26_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_25_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_25_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_24_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_24_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_23_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_23_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_22_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_22_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_21_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_21_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_20_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_20_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_19_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_19_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_18_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_18_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_17_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_17_out_ap_vld;
wire   [31:0] grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_16_out;
wire    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_16_out_ap_vld;
wire    grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_start;
wire    grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_done;
wire    grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_idle;
wire    grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_ready;
wire   [31:0] grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_p_out;
wire    grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_p_out_ap_vld;
reg    grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_start_reg;
wire   [0:0] icmp_ln30_1_fu_246_p2;
wire    ap_CS_fsm_state3;
reg   [31:0] local_Query_15_fu_146;
reg   [31:0] local_Query_14_fu_142;
reg   [31:0] local_Query_13_fu_138;
reg   [31:0] local_Query_12_fu_134;
reg   [31:0] local_Query_11_fu_130;
reg   [31:0] local_Query_10_fu_126;
reg   [31:0] local_Query_9_fu_122;
reg   [31:0] local_Query_8_fu_118;
reg   [31:0] local_Query_7_fu_114;
reg   [31:0] local_Query_6_fu_110;
reg   [31:0] local_Query_5_fu_106;
reg   [31:0] local_Query_4_fu_102;
reg   [31:0] local_Query_3_fu_98;
reg   [31:0] local_Query_2_fu_94;
reg   [31:0] local_Query_1_fu_90;
reg   [31:0] local_Query_fu_86;
reg    grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_start_reg;
wire    ap_CS_fsm_state4;
reg   [2:0] i_fu_78;
wire   [2:0] i_2_fu_252_p2;
reg   [4:0] indvars_iv114_fu_82;
wire   [4:0] add_ln30_fu_297_p2;
reg   [4:0] indvars_iv1_fu_150;
wire   [4:0] add_ln30_1_fu_303_p2;
reg   [5:0] phi_ln30_fu_154;
wire   [5:0] add_ln30_2_fu_309_p2;
wire    ap_CS_fsm_state5;
wire   [0:0] icmp_ln30_fu_272_p2;
wire   [3:0] trunc_ln30_fu_268_p1;
wire   [3:0] select_ln30_fu_278_p3;
wire  signed [4:0] sext_ln30_fu_286_p1;
reg   [4:0] ap_NS_fsm;
reg    ap_ST_fsm_state1_blk;
wire    ap_ST_fsm_state2_blk;
reg    ap_ST_fsm_state3_blk;
reg    ap_ST_fsm_state4_blk;
wire    ap_ST_fsm_state5_blk;
wire    ap_ce_reg;

// power-on initialization
initial begin
#0 ap_CS_fsm = 5'd1;
#0 grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_start_reg = 1'b0;
#0 grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_start_reg = 1'b0;
#0 i_fu_78 = 3'd0;
#0 indvars_iv114_fu_82 = 5'd0;
#0 indvars_iv1_fu_150 = 5'd0;
#0 phi_ln30_fu_154 = 6'd0;
end

compute_KNN_compute_KNN_Pipeline_VITIS_LOOP_36_1 grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175(
    .ap_clk(ap_clk),
    .ap_rst(ap_rst_n_inv),
    .ap_start(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_start),
    .ap_done(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_done),
    .ap_idle(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_idle),
    .ap_ready(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_ready),
    .indvars_iv114(indvars_iv114_load_reg_579),
    .sub_ln30(sub_ln30_reg_584),
    .cur_data(load_to_compute_stream),
    .local_Query_31_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_31_out),
    .local_Query_31_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_31_out_ap_vld),
    .local_Query_30_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_30_out),
    .local_Query_30_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_30_out_ap_vld),
    .local_Query_29_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_29_out),
    .local_Query_29_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_29_out_ap_vld),
    .local_Query_28_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_28_out),
    .local_Query_28_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_28_out_ap_vld),
    .local_Query_27_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_27_out),
    .local_Query_27_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_27_out_ap_vld),
    .local_Query_26_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_26_out),
    .local_Query_26_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_26_out_ap_vld),
    .local_Query_25_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_25_out),
    .local_Query_25_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_25_out_ap_vld),
    .local_Query_24_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_24_out),
    .local_Query_24_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_24_out_ap_vld),
    .local_Query_23_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_23_out),
    .local_Query_23_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_23_out_ap_vld),
    .local_Query_22_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_22_out),
    .local_Query_22_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_22_out_ap_vld),
    .local_Query_21_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_21_out),
    .local_Query_21_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_21_out_ap_vld),
    .local_Query_20_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_20_out),
    .local_Query_20_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_20_out_ap_vld),
    .local_Query_19_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_19_out),
    .local_Query_19_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_19_out_ap_vld),
    .local_Query_18_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_18_out),
    .local_Query_18_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_18_out_ap_vld),
    .local_Query_17_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_17_out),
    .local_Query_17_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_17_out_ap_vld),
    .local_Query_16_out(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_16_out),
    .local_Query_16_out_ap_vld(grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_16_out_ap_vld)
);

compute_KNN_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2 grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198(
    .ap_clk(ap_clk),
    .ap_rst(ap_rst_n_inv),
    .ap_start(grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_start),
    .ap_done(grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_done),
    .ap_idle(grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_idle),
    .ap_ready(grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_ready),
    .local_Query(local_Query_fu_86),
    .local_Query_4(local_Query_4_fu_102),
    .local_Query_8(local_Query_8_fu_118),
    .local_Query_12(local_Query_12_fu_134),
    .conv_i_i25_i340(trunc_ln61_reg_669),
    .local_Query_1(local_Query_1_fu_90),
    .local_Query_5(local_Query_5_fu_106),
    .local_Query_9(local_Query_9_fu_122),
    .local_Query_13(local_Query_13_fu_138),
    .conv_i_i25_i340_1(sp_dim_item_value_s_reg_674),
    .local_Query_2(local_Query_2_fu_94),
    .local_Query_6(local_Query_6_fu_110),
    .local_Query_10(local_Query_10_fu_126),
    .local_Query_14(local_Query_14_fu_142),
    .conv_i_i25_i340_2(sp_dim_item_value_1_reg_679),
    .local_Query_3(local_Query_3_fu_98),
    .local_Query_7(local_Query_7_fu_114),
    .local_Query_11(local_Query_11_fu_130),
    .local_Query_15(local_Query_15_fu_146),
    .conv_i_i25_i340_3(sp_dim_item_value_2_reg_684),
    .p_out(grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_p_out),
    .p_out_ap_vld(grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_p_out_ap_vld)
);

always @ (posedge ap_clk) begin
    if (ap_rst_n_inv == 1'b1) begin
        ap_CS_fsm <= ap_ST_fsm_state1;
    end else begin
        ap_CS_fsm <= ap_NS_fsm;
    end
end

always @ (posedge ap_clk) begin
    if (ap_rst_n_inv == 1'b1) begin
        grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_start_reg <= 1'b0;
    end else begin
        if (((1'b1 == ap_CS_fsm_state2) & (icmp_ln30_1_fu_246_p2 == 1'd1))) begin
            grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_start_reg <= 1'b1;
        end else if ((grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_ready == 1'b1)) begin
            grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_start_reg <= 1'b0;
        end
    end
end

always @ (posedge ap_clk) begin
    if (ap_rst_n_inv == 1'b1) begin
        grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_start_reg <= 1'b0;
    end else begin
        if (((1'b1 == ap_CS_fsm_state2) & (icmp_ln30_1_fu_246_p2 == 1'd0))) begin
            grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_start_reg <= 1'b1;
        end else if ((grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_ready == 1'b1)) begin
            grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_start_reg <= 1'b0;
        end
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state1) & (ap_start == 1'b1))) begin
        i_fu_78 <= 3'd0;
    end else if (((1'b1 == ap_CS_fsm_state2) & (icmp_ln30_1_fu_246_p2 == 1'd0))) begin
        i_fu_78 <= i_2_fu_252_p2;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state1) & (ap_start == 1'b1))) begin
        indvars_iv114_fu_82 <= 5'd0;
    end else if (((1'b1 == ap_CS_fsm_state2) & (icmp_ln30_1_fu_246_p2 == 1'd0))) begin
        indvars_iv114_fu_82 <= add_ln30_fu_297_p2;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state1) & (ap_start == 1'b1))) begin
        indvars_iv1_fu_150 <= 5'd31;
    end else if (((1'b1 == ap_CS_fsm_state2) & (icmp_ln30_1_fu_246_p2 == 1'd0))) begin
        indvars_iv1_fu_150 <= add_ln30_1_fu_303_p2;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state1) & (ap_start == 1'b1))) begin
        phi_ln30_fu_154 <= 6'd47;
    end else if (((1'b1 == ap_CS_fsm_state2) & (icmp_ln30_1_fu_246_p2 == 1'd0))) begin
        phi_ln30_fu_154 <= add_ln30_2_fu_309_p2;
    end
end

always @ (posedge ap_clk) begin
    if ((1'b1 == ap_CS_fsm_state2)) begin
        indvars_iv114_load_reg_579 <= indvars_iv114_fu_82;
        sp_dim_item_value_1_reg_679 <= {{load_to_compute_stream[95:64]}};
        sp_dim_item_value_2_reg_684 <= {{load_to_compute_stream[127:96]}};
        sp_dim_item_value_s_reg_674 <= {{load_to_compute_stream[63:32]}};
        sub_ln30_reg_584 <= sub_ln30_fu_290_p2;
        trunc_ln61_reg_669 <= trunc_ln61_fu_399_p1;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state3) & (grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_26_out_ap_vld == 1'b1))) begin
        local_Query_10_fu_126 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_26_out;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state3) & (grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_27_out_ap_vld == 1'b1))) begin
        local_Query_11_fu_130 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_27_out;
    end
end

always @ (posedge ap_clk) begin
    if (((grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_28_out_ap_vld == 1'b1) & (1'b1 == ap_CS_fsm_state3))) begin
        local_Query_12_fu_134 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_28_out;
    end
end

always @ (posedge ap_clk) begin
    if (((grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_29_out_ap_vld == 1'b1) & (1'b1 == ap_CS_fsm_state3))) begin
        local_Query_13_fu_138 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_29_out;
    end
end

always @ (posedge ap_clk) begin
    if (((grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_30_out_ap_vld == 1'b1) & (1'b1 == ap_CS_fsm_state3))) begin
        local_Query_14_fu_142 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_30_out;
    end
end

always @ (posedge ap_clk) begin
    if (((grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_31_out_ap_vld == 1'b1) & (1'b1 == ap_CS_fsm_state3))) begin
        local_Query_15_fu_146 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_31_out;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state3) & (grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_17_out_ap_vld == 1'b1))) begin
        local_Query_1_fu_90 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_17_out;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state3) & (grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_18_out_ap_vld == 1'b1))) begin
        local_Query_2_fu_94 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_18_out;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state3) & (grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_19_out_ap_vld == 1'b1))) begin
        local_Query_3_fu_98 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_19_out;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state3) & (grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_20_out_ap_vld == 1'b1))) begin
        local_Query_4_fu_102 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_20_out;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state3) & (grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_21_out_ap_vld == 1'b1))) begin
        local_Query_5_fu_106 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_21_out;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state3) & (grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_22_out_ap_vld == 1'b1))) begin
        local_Query_6_fu_110 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_22_out;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state3) & (grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_23_out_ap_vld == 1'b1))) begin
        local_Query_7_fu_114 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_23_out;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state3) & (grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_24_out_ap_vld == 1'b1))) begin
        local_Query_8_fu_118 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_24_out;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state3) & (grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_25_out_ap_vld == 1'b1))) begin
        local_Query_9_fu_122 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_25_out;
    end
end

always @ (posedge ap_clk) begin
    if (((1'b1 == ap_CS_fsm_state3) & (grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_16_out_ap_vld == 1'b1))) begin
        local_Query_fu_86 <= grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_local_Query_16_out;
    end
end

always @ (*) begin
    if ((ap_start == 1'b0)) begin
        ap_ST_fsm_state1_blk = 1'b1;
    end else begin
        ap_ST_fsm_state1_blk = 1'b0;
    end
end

assign ap_ST_fsm_state2_blk = 1'b0;

always @ (*) begin
    if ((grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_done == 1'b0)) begin
        ap_ST_fsm_state3_blk = 1'b1;
    end else begin
        ap_ST_fsm_state3_blk = 1'b0;
    end
end

always @ (*) begin
    if ((grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_done == 1'b0)) begin
        ap_ST_fsm_state4_blk = 1'b1;
    end else begin
        ap_ST_fsm_state4_blk = 1'b0;
    end
end

assign ap_ST_fsm_state5_blk = 1'b0;

always @ (*) begin
    if ((1'b1 == ap_CS_fsm_state5)) begin
        ap_done = 1'b1;
    end else begin
        ap_done = 1'b0;
    end
end

always @ (*) begin
    if (((1'b1 == ap_CS_fsm_state1) & (ap_start == 1'b0))) begin
        ap_idle = 1'b1;
    end else begin
        ap_idle = 1'b0;
    end
end

always @ (*) begin
    if ((1'b1 == ap_CS_fsm_state5)) begin
        ap_ready = 1'b1;
    end else begin
        ap_ready = 1'b0;
    end
end

always @ (*) begin
    if ((1'b1 == ap_CS_fsm_state5)) begin
        compute_to_sort_stream_ap_vld = 1'b1;
    end else begin
        compute_to_sort_stream_ap_vld = 1'b0;
    end
end

always @ (*) begin
    case (ap_CS_fsm)
        ap_ST_fsm_state1 : begin
            if (((1'b1 == ap_CS_fsm_state1) & (ap_start == 1'b1))) begin
                ap_NS_fsm = ap_ST_fsm_state2;
            end else begin
                ap_NS_fsm = ap_ST_fsm_state1;
            end
        end
        ap_ST_fsm_state2 : begin
            if (((1'b1 == ap_CS_fsm_state2) & (icmp_ln30_1_fu_246_p2 == 1'd1))) begin
                ap_NS_fsm = ap_ST_fsm_state4;
            end else begin
                ap_NS_fsm = ap_ST_fsm_state3;
            end
        end
        ap_ST_fsm_state3 : begin
            if (((grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_done == 1'b1) & (1'b1 == ap_CS_fsm_state3))) begin
                ap_NS_fsm = ap_ST_fsm_state2;
            end else begin
                ap_NS_fsm = ap_ST_fsm_state3;
            end
        end
        ap_ST_fsm_state4 : begin
            if (((1'b1 == ap_CS_fsm_state4) & (grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_done == 1'b1))) begin
                ap_NS_fsm = ap_ST_fsm_state5;
            end else begin
                ap_NS_fsm = ap_ST_fsm_state4;
            end
        end
        ap_ST_fsm_state5 : begin
            ap_NS_fsm = ap_ST_fsm_state1;
        end
        default : begin
            ap_NS_fsm = 'bx;
        end
    endcase
end

assign add_ln30_1_fu_303_p2 = (indvars_iv1_fu_150 + 5'd4);

assign add_ln30_2_fu_309_p2 = (phi_ln30_fu_154 + 6'd4);

assign add_ln30_fu_297_p2 = (indvars_iv114_fu_82 + 5'd4);

assign ap_CS_fsm_state1 = ap_CS_fsm[32'd0];

assign ap_CS_fsm_state2 = ap_CS_fsm[32'd1];

assign ap_CS_fsm_state3 = ap_CS_fsm[32'd2];

assign ap_CS_fsm_state4 = ap_CS_fsm[32'd3];

assign ap_CS_fsm_state5 = ap_CS_fsm[32'd4];

always @ (*) begin
    ap_rst_n_inv = ~ap_rst_n;
end

assign compute_to_sort_stream = grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_p_out;

assign grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_start = grp_compute_KNN_Pipeline_COMPUTE_DATA_VITIS_LOOP_50_2_fu_198_ap_start_reg;

assign grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_start = grp_compute_KNN_Pipeline_VITIS_LOOP_36_1_fu_175_ap_start_reg;

assign i_2_fu_252_p2 = (i_fu_78 + 3'd1);

assign icmp_ln30_1_fu_246_p2 = ((i_fu_78 == 3'd4) ? 1'b1 : 1'b0);

assign icmp_ln30_fu_272_p2 = ((phi_ln30_fu_154 > 6'd59) ? 1'b1 : 1'b0);

assign select_ln30_fu_278_p3 = ((icmp_ln30_fu_272_p2[0:0] == 1'b1) ? trunc_ln30_fu_268_p1 : 4'd11);

assign sext_ln30_fu_286_p1 = $signed(select_ln30_fu_278_p3);

assign sub_ln30_fu_290_p2 = ($signed(indvars_iv1_fu_150) - $signed(sext_ln30_fu_286_p1));

assign trunc_ln30_fu_268_p1 = phi_ln30_fu_154[3:0];

assign trunc_ln61_fu_399_p1 = load_to_compute_stream[31:0];

endmodule