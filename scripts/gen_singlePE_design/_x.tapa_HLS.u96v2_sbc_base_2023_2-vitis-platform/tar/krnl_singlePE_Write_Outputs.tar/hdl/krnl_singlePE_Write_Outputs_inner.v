module krnl_singlePE_Write_Outputs_inner (
        ap_clk,
        ap_rst_n,
        ap_start,
        ap_done,
        ap_idle,
        ap_ready,
        in_dist0,
        in_id0,
        output_knn_read_addr,
        output_knn_read_data,
        output_knn_write_addr,
        output_knn_write_addr_ap_vld,
        output_knn_write_data,
        output_knn_write_data_ap_vld,
        output_knn_write_resp
);

parameter    ap_ST_fsm_state1 = 3'd1;
parameter    ap_ST_fsm_state2 = 3'd2;
parameter    ap_ST_fsm_state3 = 3'd4;

input   ap_clk;
input   ap_rst_n;
input   ap_start;
output   ap_done;
output   ap_idle;
output   ap_ready;
input  [31:0] in_dist0;
input  [31:0] in_id0;
input  [63:0] output_knn_read_addr;
input  [31:0] output_knn_read_data;
output  [63:0] output_knn_write_addr;
output   output_knn_write_addr_ap_vld;
output  [31:0] output_knn_write_data;
output   output_knn_write_data_ap_vld;
input  [7:0] output_knn_write_resp;

reg ap_done;
reg ap_idle;
reg ap_ready;
reg output_knn_write_addr_ap_vld;
reg output_knn_write_data_ap_vld;

 reg    ap_rst_n_inv;
(* fsm_encoding = "none" *) reg   [2:0] ap_CS_fsm;
wire    ap_CS_fsm_state1;
wire    grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_start;
wire    grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_done;
wire    grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_idle;
wire    grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_ready;
wire   [0:0] grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_addr_flag_0_out;
wire    grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_addr_flag_0_out_ap_vld;
wire   [63:0] grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_addr_new_0_out;
wire    grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_addr_new_0_out_ap_vld;
wire   [0:0] grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_data_flag_0_out;
wire    grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_data_flag_0_out_ap_vld;
wire   [31:0] grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_data_new_0_out;
wire    grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_data_new_0_out_ap_vld;
reg    grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_start_reg;
wire    ap_CS_fsm_state2;
wire    ap_CS_fsm_state3;
wire   [0:0] output_knn_write_data_flag_0_loc_load_load_fu_101_p1;
wire   [0:0] output_knn_write_addr_flag_0_loc_load_load_fu_94_p1;
reg   [2:0] ap_NS_fsm;
reg    ap_ST_fsm_state1_blk;
reg    ap_ST_fsm_state2_blk;
wire    ap_ST_fsm_state3_blk;
wire    ap_ce_reg;

// power-on initialization
initial begin
#0 ap_CS_fsm = 3'd1;
#0 grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_start_reg = 1'b0;
end

krnl_singlePE_Write_Outputs_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1 grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82(
    .ap_clk(ap_clk),
    .ap_rst(ap_rst_n_inv),
    .ap_start(grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_start),
    .ap_done(grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_done),
    .ap_idle(grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_idle),
    .ap_ready(grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_ready),
    .cur_dist(in_dist0),
    .cur_id(in_id0),
    .output_knn_write_addr_flag_0_out(grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_addr_flag_0_out),
    .output_knn_write_addr_flag_0_out_ap_vld(grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_addr_flag_0_out_ap_vld),
    .output_knn_write_addr_new_0_out(grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_addr_new_0_out),
    .output_knn_write_addr_new_0_out_ap_vld(grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_addr_new_0_out_ap_vld),
    .output_knn_write_data_flag_0_out(grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_data_flag_0_out),
    .output_knn_write_data_flag_0_out_ap_vld(grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_data_flag_0_out_ap_vld),
    .output_knn_write_data_new_0_out(grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_data_new_0_out),
    .output_knn_write_data_new_0_out_ap_vld(grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_data_new_0_out_ap_vld)
);

always @ (posedge ap_clk) begin
    if (ap_rst_n_inv == 1'b1) begin
        ap_CS_fsm <= ap_ST_fsm_state1;
    end else begin
        ap_CS_fsm <= ap_NS_fsm;
    end
end

always @ (posedge ap_clk) begin
    if (ap_rst_n_inv == 1'b1) begin
        grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_start_reg <= 1'b0;
    end else begin
        if (((1'b1 == ap_CS_fsm_state1) & (ap_start == 1'b1))) begin
            grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_start_reg <= 1'b1;
        end else if ((grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_ready == 1'b1)) begin
            grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_start_reg <= 1'b0;
        end
    end
end

always @ (*) begin
    if ((ap_start == 1'b0)) begin
        ap_ST_fsm_state1_blk = 1'b1;
    end else begin
        ap_ST_fsm_state1_blk = 1'b0;
    end
end

always @ (*) begin
    if ((grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_done == 1'b0)) begin
        ap_ST_fsm_state2_blk = 1'b1;
    end else begin
        ap_ST_fsm_state2_blk = 1'b0;
    end
end

assign ap_ST_fsm_state3_blk = 1'b0;

always @ (*) begin
    if ((1'b1 == ap_CS_fsm_state3)) begin
        ap_done = 1'b1;
    end else begin
        ap_done = 1'b0;
    end
end

always @ (*) begin
    if (((1'b1 == ap_CS_fsm_state1) & (ap_start == 1'b0))) begin
        ap_idle = 1'b1;
    end else begin
        ap_idle = 1'b0;
    end
end

always @ (*) begin
    if ((1'b1 == ap_CS_fsm_state3)) begin
        ap_ready = 1'b1;
    end else begin
        ap_ready = 1'b0;
    end
end

always @ (*) begin
    if (((output_knn_write_addr_flag_0_loc_load_load_fu_94_p1 == 1'd1) & (1'b1 == ap_CS_fsm_state3))) begin
        output_knn_write_addr_ap_vld = 1'b1;
    end else begin
        output_knn_write_addr_ap_vld = 1'b0;
    end
end

always @ (*) begin
    if (((output_knn_write_data_flag_0_loc_load_load_fu_101_p1 == 1'd1) & (1'b1 == ap_CS_fsm_state3))) begin
        output_knn_write_data_ap_vld = 1'b1;
    end else begin
        output_knn_write_data_ap_vld = 1'b0;
    end
end

always @ (*) begin
    case (ap_CS_fsm)
        ap_ST_fsm_state1 : begin
            if (((1'b1 == ap_CS_fsm_state1) & (ap_start == 1'b1))) begin
                ap_NS_fsm = ap_ST_fsm_state2;
            end else begin
                ap_NS_fsm = ap_ST_fsm_state1;
            end
        end
        ap_ST_fsm_state2 : begin
            if (((grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_done == 1'b1) & (1'b1 == ap_CS_fsm_state2))) begin
                ap_NS_fsm = ap_ST_fsm_state3;
            end else begin
                ap_NS_fsm = ap_ST_fsm_state2;
            end
        end
        ap_ST_fsm_state3 : begin
            ap_NS_fsm = ap_ST_fsm_state1;
        end
        default : begin
            ap_NS_fsm = 'bx;
        end
    endcase
end

assign ap_CS_fsm_state1 = ap_CS_fsm[32'd0];

assign ap_CS_fsm_state2 = ap_CS_fsm[32'd1];

assign ap_CS_fsm_state3 = ap_CS_fsm[32'd2];

always @ (*) begin
    ap_rst_n_inv = ~ap_rst_n;
end

assign grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_start = grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_ap_start_reg;

assign output_knn_write_addr = grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_addr_new_0_out;

assign output_knn_write_addr_flag_0_loc_load_load_fu_94_p1 = grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_addr_flag_0_out;

assign output_knn_write_data = grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_data_new_0_out;

assign output_knn_write_data_flag_0_loc_load_load_fu_101_p1 = grp_krnl_singlePE_Write_Outputs_Pipeline_VITIS_LOOP_23_1_fu_82_output_knn_write_data_flag_0_out;

endmodule